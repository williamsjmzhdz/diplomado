package tech.hxadev.unam.entities;

import lombok.Builder;
/**
 * @author <a href="https://github.com/hxadev">HXADEV</a>
 * @since 1.0
 */
@lombok.Data
@Builder
public class GenerationInfo {
    private String prompt;
}
