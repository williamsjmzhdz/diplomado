package tech.hxadev.unam.view.strategy;

public interface MenuStrategy {
    void execute();
}
