package edu.dgtic.lsp;

public interface Shape {
    int computeArea();
}
