package com.hxadev.unam.producto.ejercicio;
/**
 * @autor Alumno: Jiménez Hernández Francisco Williams
 * @fecha 19/06/2024
 */
public enum EstadoPedido {
    NO_PAGADO,
    PAGADO,
    CANCELADO
}