package mx.unam.dgtic.handlers.abstractHandler;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface Handler {
    boolean authenticate(String email, String pwd);
    boolean authorize(String email, String request);
     boolean processRequest(String email, String request);
     boolean hasNextHandler();
     boolean delegateNextHandler(String email, String request);
     public void setNextHandler(Handler nextHandler);
}
