package mx.unam.dgtic;

import mx.unam.dgtic.handlers.AuthenticationHandler;
import mx.unam.dgtic.handlers.CreditBalanceHandler;
import mx.unam.dgtic.handlers.RiskAssessmentHandler;
import mx.unam.dgtic.handlers.abstractHandler.Handler;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Handler authenticationHandler=new AuthenticationHandler();
        Handler creditLimitHandler=new CreditBalanceHandler();
        Handler riskAssessmentHandler=new RiskAssessmentHandler();

        authenticationHandler.setNextHandler(creditLimitHandler);
        creditLimitHandler.setNextHandler(riskAssessmentHandler);

        String user="persona123@gmail.com";
        String request="admin123";

        authenticationHandler.processRequest(user,request);
    }
}