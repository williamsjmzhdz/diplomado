package mx.unam.dgtic.handlers;

import mx.unam.dgtic.handlers.abstractHandler.AbstractHandler;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class CreditBalanceHandler extends AbstractHandler {
    @Override
    public boolean authenticate(String email, String pwd) {
        System.out.println("CreditBalanceHandler: Authenticate...");
        return delegateNextHandler(email,pwd);
    }

    @Override
    public boolean authorize(String email, String request) {
        System.out.println("CreditBalanceHandler: Authorize...");

        if(Integer.parseInt(request)>0 && email.equals("persona123@gmail.com")){
            return delegateNextHandler(email, request);
        }else
            return false;
    }
}
