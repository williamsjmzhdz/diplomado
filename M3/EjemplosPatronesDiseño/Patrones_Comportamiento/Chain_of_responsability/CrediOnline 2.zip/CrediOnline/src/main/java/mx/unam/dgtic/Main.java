package mx.unam.dgtic;

import mx.unam.dgtic.handlers.AuthenticationHandler;
import mx.unam.dgtic.handlers.CreditBalanceHandler;
import mx.unam.dgtic.handlers.RiskAssessmentHandler;
import mx.unam.dgtic.handlers.abstractHandler.Handler;
import mx.unam.dgtic.model.Request;
import mx.unam.dgtic.model.User;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Handler authenticationHandler=new AuthenticationHandler();
        Handler creditLimitHandler=new CreditBalanceHandler();
        Handler riskAssessmentHandler=new RiskAssessmentHandler();

        authenticationHandler.setNextHandler(creditLimitHandler);
        creditLimitHandler.setNextHandler(riskAssessmentHandler);

        User userRequest=new User("persona123@gmail.com","admin123","Jhon",90,0.9,80);
        Request request=new Request(userRequest,50,10000);
        authenticationHandler.processRequest(userRequest,request);
    }
}