package mx.unam.dgtic.views;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class UserView {
    public void printUserDetails(String username, String password){
        System.out.println("Username: "+username+", Password: "+password);
    }
}
