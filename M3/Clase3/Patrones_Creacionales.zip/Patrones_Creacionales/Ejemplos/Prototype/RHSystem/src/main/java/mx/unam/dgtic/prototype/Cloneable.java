package mx.unam.dgtic.prototype;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface Cloneable {
    Employee clone();
}
