package mx.unam.dgtic.abstractFactoryImplV1_0.ecommerce.products.abstractProduct;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface Product {
    void display();
    void sell();
    void delete();
}
