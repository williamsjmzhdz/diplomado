package mx.unam.dgtic.abstractFactoryImplV2_0.ecommerce.enums;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public enum ElectronicType {
    TV,
    COMPUTER,
    PHONE,
    VIDEOGAME,
    UNDEFINED
}
