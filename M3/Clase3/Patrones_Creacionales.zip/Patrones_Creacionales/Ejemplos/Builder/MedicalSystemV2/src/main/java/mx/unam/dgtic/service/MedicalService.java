package mx.unam.dgtic.service;

import mx.unam.dgtic.models.MedicalRecord;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface MedicalService {
    void createAppointment(MedicalRecord record);

}
