package com.unam.dgtic.service;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface BalanceVerificationService {
    double checkBalance(String userId);
}
