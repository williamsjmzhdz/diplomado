package mx.unam.dgtic.adapters;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface LogProcessor {
    void processLog(String log);
}
