package mx.unam.dgtic.client;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/

public interface OnfidoClient {
    void sendValidationOnfido(String username, String email);
}
