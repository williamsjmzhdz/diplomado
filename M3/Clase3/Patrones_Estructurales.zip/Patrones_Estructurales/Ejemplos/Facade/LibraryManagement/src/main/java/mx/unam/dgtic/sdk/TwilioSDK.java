package mx.unam.dgtic.sdk;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class TwilioSDK {
   public static void sendNotification(String phoneNumber){
        // send notification...
    }
}
