package mx.unam.dgtic.command;

import mx.unam.dgtic.models.Order;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class UpdateOrderCommand implements Command{
    private Order order;

    public UpdateOrderCommand(Order order, String status) {
        this.order = order;
        this.order.setStatus(status);
        System.out.println("INITIAL STATUS: "+order.getStatus());

    }

    @Override
    public void execute() {
        System.out.println("New Order Updated "+order);
        System.out.println("STATUS: "+order.getStatus());
    }
}
