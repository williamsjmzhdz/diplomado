package mx.unam.dgtic;

import mx.unam.dgtic.command.Command;
import mx.unam.dgtic.command.CreateOrderCommand;
import mx.unam.dgtic.command.UpdateOrderCommand;
import mx.unam.dgtic.invoker.OrderProcessor;
import mx.unam.dgtic.models.Order;

import java.util.List;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        OrderProcessor orderProcessor=new OrderProcessor();

        Order order1=new Order("ORDER N1","CHILLIS", List.of("HAMBURGUER STEAK","COCA COLA","CROISSANT","FRIES"),"US-1221",1000,"SENT");

        Command orderCommand=new CreateOrderCommand(order1);
        orderProcessor.receiveCommand(orderCommand);

        Command updateCommand=new UpdateOrderCommand(order1,"RECEIVED");
        orderProcessor.receiveCommand(updateCommand);

        Command updateCommand2=new UpdateOrderCommand(order1,"COOKING");
        orderProcessor.receiveCommand(updateCommand2);

        Command updateCommand3=new UpdateOrderCommand(order1,"DONE");
        orderProcessor.receiveCommand(updateCommand3);

        orderProcessor.processOrder();
    }
}