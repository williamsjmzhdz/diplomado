package mx.unam.dgtic.invoker;

import mx.unam.dgtic.command.Command;

import java.util.LinkedList;
import java.util.Queue;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class OrderProcessor {
    private Queue<Command> commandQueue;

    public OrderProcessor() {
        commandQueue=new LinkedList<>();
    }

    public void receiveCommand(Command command){
        commandQueue.offer(command);
    }

    public void processOrder(){
        while(!commandQueue.isEmpty()){
            Command command=commandQueue.poll();
            command.execute();
        }
    }
}
