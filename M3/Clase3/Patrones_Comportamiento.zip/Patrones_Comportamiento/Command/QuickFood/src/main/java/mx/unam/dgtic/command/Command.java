package mx.unam.dgtic.command;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface Command {
    void execute();
}
