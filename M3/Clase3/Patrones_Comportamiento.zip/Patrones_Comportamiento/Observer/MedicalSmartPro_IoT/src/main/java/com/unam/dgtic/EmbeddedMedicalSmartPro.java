package com.unam.dgtic;

import com.unam.dgtic.observer.DoctorDevice;
import com.unam.dgtic.observer.EmergencyNotificationSystem;
import com.unam.dgtic.observer.HealthObserver;
import com.unam.dgtic.observer.PatientDevice;
import com.unam.dgtic.publisher.HealthPublisher;
import com.unam.dgtic.publisher.Publisher;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class EmbeddedMedicalSmartPro {
    public static void run(String version){
        synchronized (version){
            try {
                System.out.println("Embedded Medical Smart Pro - Running Version "+version);
                // Creamos un nuevo publicador Health
                Publisher publisher=new HealthPublisher();

                // Cramos nuestros observers.
                HealthObserver patientDevice1=new PatientDevice("ALEX GOMEZ PHONE");
                HealthObserver patientDevice2=new PatientDevice("ALEX GOMEZ TABLET");
                HealthObserver doctorPatient=new DoctorDevice("ALEX GOMEZ","Dr. JHON PHONE");
                HealthObserver emergencySystem=new EmergencyNotificationSystem("EMERGENCY");

                // Subscribimos nuestros observers al publicador.
                publisher.subscribe(patientDevice1);
                publisher.subscribe(patientDevice2);
                publisher.subscribe(doctorPatient);
                publisher.subscribe(emergencySystem);

                // Comenzamos a publicar mensajes para que los suscriptores lo reciban y cambien su estado.
                publisher.detectAnomaly("ARRHYTMIA");
                Thread.sleep(3000);
                publisher.detectAnomaly("ARRHYTMIA");
                Thread.sleep(3000);
                publisher.detectAnomaly("ARRHYTMIA");
                Thread.sleep(3000);
                publisher.detectAnomaly("ARRHYTMIA");
                Thread.sleep(3000);
                publisher.detectAnomaly("ARRHYTMIA");
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }


        }
    }
}
