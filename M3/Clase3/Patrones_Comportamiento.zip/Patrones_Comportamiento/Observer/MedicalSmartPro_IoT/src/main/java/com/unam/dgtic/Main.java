package com.unam.dgtic;

import java.util.UUID;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class Main {
    public static void main(String[] args) {
        EmbeddedMedicalSmartPro.run(UUID.randomUUID().toString());
    }

}