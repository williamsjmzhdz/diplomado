package mx.unam.dgtic.handlers.abstractHandler;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public abstract class AbstractHandler implements Handler {
    private Handler nextHandler;

    @Override
    public abstract boolean authenticate(String email, String pwd);

    @Override
    public abstract boolean authorize(String email, String request);

    @Override
    public boolean processRequest(String email, String request) {
        if(authenticate(email, request)){
            if(authorize(email, request)){
                System.out.println("Authorization granted for Balance Credit Request");
                return true;
            }else{
                System.out.println("Authorization denied for Balance Credit Request");
                return false;
            }
        }else{
            throw new RuntimeException("Authentication Failed");
        }
    }

    public void setNextHandler(Handler nextHandler) {
        this.nextHandler = nextHandler;
    }

    @Override
    public boolean hasNextHandler() {
        return nextHandler!=null;
    }

    @Override
    public boolean delegateNextHandler(String email, String request) {
        if(hasNextHandler()){
            return nextHandler.processRequest(email, request);
        }
        return false;
    }
}
