package mx.unam.dgtic.handlers;

import mx.unam.dgtic.handlers.abstractHandler.AbstractHandler;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class AuthenticationHandler extends AbstractHandler {
    @Override
    public boolean authenticate(String email, String pwd) {
        System.out.println("AuthenticationHandler: Authenticate...");
        // Aqui deberia de estar alguna conexion en la base de datos o conexion con algun servicio de autenticacion como Auth0 o Firebase.
        return (email.equals("persona123@gmail.com") && pwd.equals("admin123"));
    }

    @Override
    public boolean authorize(String email, String request) {
        System.out.println("AuthenticationHandler: Authorize...");

        return delegateNextHandler(email, request);
    }
}
