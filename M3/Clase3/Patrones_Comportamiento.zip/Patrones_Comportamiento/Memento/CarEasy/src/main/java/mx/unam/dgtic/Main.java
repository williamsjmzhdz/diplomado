package mx.unam.dgtic;

import mx.unam.dgtic.state.OnboardingState;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        UserRegistrationManager registrationManager=new UserRegistrationManager();

        registrationManager.setFirstName("JHON");
        registrationManager.setLastName("MIRA");
        registrationManager.setDocument("CURP: 123123123");
        registrationManager.setStep("ONBOARDING_START");

        registrationManager.saveRegistration();

        printCurrentState(registrationManager.getState());

        registrationManager.setStep("NAME_VALIDATION_START");
        registrationManager.saveRegistration();

        printCurrentState(registrationManager.getState());


        registrationManager.setStep("NAME_VALIDATION_SUCCESS");
        registrationManager.saveRegistration();

        printCurrentState(registrationManager.getState());


        registrationManager.setStep("DOCUMENT_VALIDATION_START");
        registrationManager.saveRegistration();

        printCurrentState(registrationManager.getState());


        registrationManager.setStep("DOCUMENT_VALIDATION_FAILED");
        printCurrentState(registrationManager.getState());


        registrationManager.undoRegistration();
        printCurrentState(registrationManager.getState());




    }

    public static void printCurrentState(OnboardingState state){
        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
        System.out.println("ONBOARDING STATE: Fullname: "+state.getName()+" "+state.getLastname()+", DOCUMENT: "+state.getDocument()+""+", Step: "+state.getStep());
    }
}