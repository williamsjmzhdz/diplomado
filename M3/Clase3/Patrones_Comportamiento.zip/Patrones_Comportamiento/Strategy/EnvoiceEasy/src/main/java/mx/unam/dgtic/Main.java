package mx.unam.dgtic;

import mx.unam.dgtic.context.TaxStrategyContext;
import mx.unam.dgtic.strategy.TaxStrategyJAM;
import mx.unam.dgtic.strategy.TaxStrategyMX;
import mx.unam.dgtic.strategy.TaxStrategySPAIN;
import mx.unam.dgtic.strategy.TaxStrategyUSA;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    static enum Countries{
        MX,
        USA,
        JAMAICA,
        ARGENTINA,
        SPAIN,
        INDIA
    }
    public static void main(String[] args) {
        TaxStrategyContext context=new TaxStrategyContext();
        Countries country=Countries.SPAIN;

        switch (country){
            case MX:
                context.setStrategy(new TaxStrategyMX());
                break;
            case SPAIN:
                context.setStrategy(new TaxStrategySPAIN());
                break;
            case USA:
                context.setStrategy(new TaxStrategyUSA());
                break;
            case JAMAICA:
                context.setStrategy(new TaxStrategyJAM());
                break;
            default:
                throw new RuntimeException("No implemented");
        }

        double originalAmount=4000;

        double totalWithTaxes= context.calcTotalWithTaxes(originalAmount);

        System.out.println("Location: "+country.name());
        System.out.println("Amount: "+originalAmount);
        System.out.println("Amount with taxes: "+totalWithTaxes);
    }
}