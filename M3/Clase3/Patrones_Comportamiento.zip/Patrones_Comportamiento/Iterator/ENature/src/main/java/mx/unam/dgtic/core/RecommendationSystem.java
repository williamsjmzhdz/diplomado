package mx.unam.dgtic.core;

import mx.unam.dgtic.iterator.RecommendationIterator;
import mx.unam.dgtic.iterator.RecommendationIteratorImpl;
import mx.unam.dgtic.models.Recommendation;

import java.util.List;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class RecommendationSystem {
    private List<Recommendation> recommendations;
    public RecommendationSystem(List<Recommendation> recommendations) {
        this.recommendations = recommendations;
    }
    public RecommendationIterator createIterator(){
        return new RecommendationIteratorImpl(recommendations);
    }
}
