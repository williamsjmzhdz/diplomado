package mx.unam.dgtic;

import mx.unam.dgtic.core.RecommendationSystem;
import mx.unam.dgtic.iterator.RecommendationIterator;
import mx.unam.dgtic.models.Recommendation;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class Main {
    public static void main(String[] args) {
        // Implementacion de Iterator con uns estructura basada en nuestros requerimientos.
        List<Recommendation> recommendations=getRecommendations();
        RecommendationSystem recommendationSystem=new RecommendationSystem(recommendations);
        RecommendationIterator iterator= recommendationSystem.createIterator();

        while(iterator.hasNext()){
            Recommendation currentRecommendation=iterator.next();
            System.out.println("Item: "+currentRecommendation.getItem()+", Score: "+currentRecommendation.getScore());
        }
    }

    private static List<Recommendation> getRecommendations(){
        List<Recommendation> recommendations=new ArrayList<>();

        for(int i=0;i<5000;i++){
            recommendations.add(new Recommendation(UUID.randomUUID().toString()+""+(i+1),Math.random()));
        }
        return recommendations;
    }
}