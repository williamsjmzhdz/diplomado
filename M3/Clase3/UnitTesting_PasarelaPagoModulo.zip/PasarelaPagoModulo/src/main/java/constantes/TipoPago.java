package constantes;

public enum TipoPago {
    EFECTIVO,
    TRANSFERENCIA,
    PAYPAL,
    CHEQUE,
    TARJETA_DEBITO,
    CODI;
}
