package mx.unam.dgtic.hxadev.marketfitness.facade;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class ShoppingCartFacade {
}
