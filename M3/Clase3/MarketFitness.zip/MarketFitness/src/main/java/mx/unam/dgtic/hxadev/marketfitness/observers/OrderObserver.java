package mx.unam.dgtic.hxadev.marketfitness.observers;

import mx.unam.dgtic.hxadev.marketfitness.entities.Order;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface OrderObserver {
    void update(Order order);
}
