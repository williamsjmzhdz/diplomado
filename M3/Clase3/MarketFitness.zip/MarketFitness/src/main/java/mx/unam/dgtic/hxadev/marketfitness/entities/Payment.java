package mx.unam.dgtic.hxadev.marketfitness.entities;

import lombok.*;

import java.time.LocalDate;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
@Builder
@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Payment {
    private double total;
    private LocalDate date;
    private Product product;
    private String uuid;
}
