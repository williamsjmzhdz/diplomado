package mx.unam.dgtic.hxadev.marketfitness.entities;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import mx.unam.dgtic.hxadev.marketfitness.observers.OrderObserver;

import java.util.List;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
@Builder
@NoArgsConstructor
@Data
@AllArgsConstructor
public class Order {
    private String uuid;
    private ShoppingCart cart;
    private User user;
    private List<OrderObserver> observers;

    public void attach(OrderObserver observer){
        observers.add(observer);
    }

    public void detach(OrderObserver observer){
        observers.remove(observer);
    }

    public void placeOrder(){
        notifyObservers();
    }

    private void notifyObservers(){
        for(var observer:observers){
            observer.update(this);
        }
    }
}
