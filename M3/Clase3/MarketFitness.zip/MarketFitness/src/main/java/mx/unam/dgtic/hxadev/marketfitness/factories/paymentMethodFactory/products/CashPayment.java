package mx.unam.dgtic.hxadev.marketfitness.factories.paymentMethodFactory.products;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class CashPayment implements PaymentMethod {
    @Override
    public void processPayment(double amount) {
        System.out.println("Processing payment");
    }
}
