package mx.unam.dgtic.hxadev.marketfitness.entities;

import lombok.*;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Product {
    private String uuid;
    private String name;
    private String type;
    private double price;
    private boolean isAvailable;
    private String description;
}
