package mx.unam.dgtic.hxadev.marketfitness.models.impl;

import mx.unam.dgtic.hxadev.marketfitness.entities.Payment;
import mx.unam.dgtic.hxadev.marketfitness.entities.ShoppingCart;
import mx.unam.dgtic.hxadev.marketfitness.models.PaymentModel;
import mx.unam.dgtic.hxadev.marketfitness.models.ShoppingCartModel;
import mx.unam.dgtic.hxadev.marketfitness.singletons.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class PaymentModelImpl implements PaymentModel {

    @Override
    public List<Payment> findAll() {
        Connection connection =DatabaseConnection.getConnection();

        return null;
    }

    @Override
    public Payment findById(String id) {
        Connection connection =DatabaseConnection.getConnection();

        return null;
    }

    @Override
    public void create(Payment shoppingCart) {
        Connection connection =DatabaseConnection.getConnection();
    }

    @Override
    public void update(String id, Payment payment) {
        Connection connection =DatabaseConnection.getConnection();

    }

    @Override
    public void delete(Payment payment) {
        Connection connection =DatabaseConnection.getConnection();

    }
}
