package mx.unam.dgtic.hxadev.marketfitness.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class ShoppingCart {
    private String uuid;
    private List<Product> products;
    private double total;
}
