package mx.unam.dgtic.hxadev.marketfitness.models;

import mx.unam.dgtic.hxadev.marketfitness.entities.Payment;
import mx.unam.dgtic.hxadev.marketfitness.entities.ShoppingCart;
import mx.unam.dgtic.hxadev.marketfitness.models.repository.Repository;

import java.util.List;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface PaymentModel extends Repository<Payment> {
    @Override
    List<Payment> findAll();

    @Override
    Payment findById(String id);

    @Override
    void create(Payment shoppingCart);

    @Override
    void update(String id, Payment payment);

    @Override
    void delete(Payment payment);
}
