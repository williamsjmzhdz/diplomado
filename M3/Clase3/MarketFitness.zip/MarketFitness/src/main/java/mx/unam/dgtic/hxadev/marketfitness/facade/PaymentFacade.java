package mx.unam.dgtic.hxadev.marketfitness.facade;

import mx.unam.dgtic.hxadev.marketfitness.entities.Payment;
import mx.unam.dgtic.hxadev.marketfitness.models.PaymentModel;
import mx.unam.dgtic.hxadev.marketfitness.models.ShoppingCartModel;

import java.util.List;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class PaymentFacade {
    private PaymentModel model;
    public List<Payment> getPayments(){
        return model.findAll();
    }

    public void updatePayment(Payment payment){
        model.update(payment.getUuid(),payment);
    }

    public void createPayment(Payment payment){
        model.create(payment);
    }

    public void deletePayment(Payment payment){
        model.delete(payment);
    }

    public void processPayment(Payment payment){
        System.out.println("Processing payment");
    }
}
