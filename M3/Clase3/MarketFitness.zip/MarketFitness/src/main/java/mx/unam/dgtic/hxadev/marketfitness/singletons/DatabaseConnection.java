package mx.unam.dgtic.hxadev.marketfitness.singletons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class DatabaseConnection {
    public static Connection getConnection(){

        Connection connection=null;
        try {
            if(connection==null)
                Class.forName("org.h2.Driver");
                connection= DriverManager.getConnection("jdbc:h2:~/ecommerce","sa","");
            return connection;
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
