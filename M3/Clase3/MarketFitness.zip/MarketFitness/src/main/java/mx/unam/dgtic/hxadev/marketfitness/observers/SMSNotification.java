package mx.unam.dgtic.hxadev.marketfitness.observers;

import mx.unam.dgtic.hxadev.marketfitness.entities.Order;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class SMSNotification implements OrderObserver{
    @Override
    public void update(Order order) {
        System.out.println("Notificacion Enviada...");
    }
}
