package mx.unam.dgtic.hxadev.marketfitness.models;

import mx.unam.dgtic.hxadev.marketfitness.entities.ShoppingCart;
import mx.unam.dgtic.hxadev.marketfitness.models.repository.Repository;

import java.util.List;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface ShoppingCartModel extends Repository<ShoppingCart> {
    @Override
    List<ShoppingCart> findAll();

    @Override
    ShoppingCart findById(String id);

    @Override
    void create(ShoppingCart shoppingCart);

    @Override
    void update(String id, ShoppingCart shoppingCart);

    @Override
    void delete(ShoppingCart shoppingCart);
}
