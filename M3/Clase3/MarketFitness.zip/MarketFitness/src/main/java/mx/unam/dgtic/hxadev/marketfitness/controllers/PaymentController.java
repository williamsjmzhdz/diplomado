package mx.unam.dgtic.hxadev.marketfitness.controllers;

import java.io.*;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import mx.unam.dgtic.hxadev.marketfitness.entities.Payment;
import mx.unam.dgtic.hxadev.marketfitness.facade.PaymentFacade;
import org.json.JSONObject;

@WebServlet(name = "paymentServlet", value = "/payment")
public class PaymentController extends HttpServlet {
    private String message;
    private PaymentFacade facade;
    private Gson gson;

    public void init() {
        message = "Hello World!";
        facade=new PaymentFacade();
        gson=new Gson();
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        var payments=facade.getPayments();
        var body=this.parseBody(request);

        // Hello
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        out.println("</body></html>");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        facade.createPayment(gson.fromJson(this.parseBody(req).toString(), Payment.class));
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        facade.updatePayment(gson.fromJson(this.parseBody(req).toString(), Payment.class));

    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        facade.deletePayment(gson.fromJson(this.parseBody(req).toString(), Payment.class));

    }

    public void destroy() {
    }

    private JSONObject parseBody(HttpServletRequest req) throws IOException {
        StringBuilder builder=new StringBuilder();
        BufferedReader requestBody=req.getReader();
        String line=null;
        while((line=requestBody.readLine())!=null){
            builder.append(line);
        }
        return new JSONObject(line);
    }
}