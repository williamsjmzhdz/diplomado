package mx.unam.dgtic.hxadev.marketfitness.factories.paymentMethodFactory.abstractFactory;

import mx.unam.dgtic.hxadev.marketfitness.factories.paymentMethodFactory.products.CashPayment;
import mx.unam.dgtic.hxadev.marketfitness.factories.paymentMethodFactory.products.CreditCardPayment;
import mx.unam.dgtic.hxadev.marketfitness.factories.paymentMethodFactory.products.PaymentMethod;
import mx.unam.dgtic.hxadev.marketfitness.factories.paymentMethodFactory.products.PaypalPayment;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class PaymentMethodFactory {
    public static PaymentMethod createPaymentMethod(String method){
        if(method.equals("CREDIT_CARD"))
            return new CreditCardPayment();
        else if(method.equals("PAYPAL"))
            return new PaypalPayment();
        else if(method.equals("OXXO"))
            return new PaypalPayment();
        else if(method.equals("CASH"))
            return new CashPayment();

        return null;
    }
}
