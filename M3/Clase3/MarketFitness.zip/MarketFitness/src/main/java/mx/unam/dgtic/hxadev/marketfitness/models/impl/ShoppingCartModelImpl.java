package mx.unam.dgtic.hxadev.marketfitness.models.impl;

import mx.unam.dgtic.hxadev.marketfitness.entities.ShoppingCart;
import mx.unam.dgtic.hxadev.marketfitness.models.ShoppingCartModel;
import mx.unam.dgtic.hxadev.marketfitness.singletons.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class ShoppingCartModelImpl implements ShoppingCartModel {
    @Override
    public List<ShoppingCart> findAll() {
        Connection connection =DatabaseConnection.getConnection();

        return null;
    }

    @Override
    public ShoppingCart findById(String id) {
        Connection connection =DatabaseConnection.getConnection();

        return null;
    }

    @Override
    public void create(ShoppingCart shoppingCart) {
        try {
            PreparedStatement stmt=DatabaseConnection.getConnection().prepareStatement("INSERT INTO cart(uuid,products,total)values(?,?,?)");
            stmt.setString(1, UUID.randomUUID().toString());
            stmt.setString(2,shoppingCart.getProducts().toString());
            stmt.setDouble(3,shoppingCart.getTotal());
            int status=stmt.executeUpdate();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    @Override
    public void update(String id, ShoppingCart shoppingCart) {
        Connection connection =DatabaseConnection.getConnection();

    }

    @Override
    public void delete(ShoppingCart shoppingCart) {
        Connection connection =DatabaseConnection.getConnection();

    }
}
