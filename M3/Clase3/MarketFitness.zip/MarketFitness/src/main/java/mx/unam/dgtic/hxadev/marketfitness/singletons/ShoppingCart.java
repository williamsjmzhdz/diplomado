package mx.unam.dgtic.hxadev.marketfitness.singletons;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public class ShoppingCart {
    private static ShoppingCart instance;

    private ShoppingCart(){}

    public static ShoppingCart getInstance(){
        if(instance==null)
            instance=new ShoppingCart();
        return instance;
    }
}
