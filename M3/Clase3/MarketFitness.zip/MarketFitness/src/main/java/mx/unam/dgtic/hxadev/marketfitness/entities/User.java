package mx.unam.dgtic.hxadev.marketfitness.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import mx.unam.dgtic.hxadev.marketfitness.singletons.ShoppingCart;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
@Data
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private String name;
    private String lastName;
    private String location;
    private String id;
    private ShoppingCart cart;
}
