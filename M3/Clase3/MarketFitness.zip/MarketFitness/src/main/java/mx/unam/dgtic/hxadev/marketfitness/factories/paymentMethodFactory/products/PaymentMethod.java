package mx.unam.dgtic.hxadev.marketfitness.factories.paymentMethodFactory.products;

/***
 ** Unidad 3 - Principios y Patrones de Diseño
 **
 **  @author: hxa.dev
 ***/
public interface PaymentMethod {
    void processPayment(double amount);
}
