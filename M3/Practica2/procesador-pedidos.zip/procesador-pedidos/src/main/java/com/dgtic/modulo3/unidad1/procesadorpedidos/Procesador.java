package com.dgtic.modulo3.unidad1.procesadorpedidos;

public interface Procesador {

    public void procesar(Pedido pedido) throws Exception;
}
