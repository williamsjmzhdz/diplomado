package dgtic.core.servicio;

public class EmpleadoServicioImpl implements EmpleadoServicio {

    @Override
    public void servicioEmpleado() {
        System.out.println("Servicio implementado");
    }
}
