package dgtic.core.servicio;

public interface EmpleadoServicio {
    void servicioEmpleado();
}
