package dgtic.core.servicio;

public interface ReporteEmpleadoServicio {
    void reporteDiario();
}
