package dgtic.core.servicio;

public class ReporteEmpleadoImpl implements ReporteEmpleadoServicio {

    @Override
    public void reporteDiario() {
        System.out.println("Reporte implementado");
    }
}
