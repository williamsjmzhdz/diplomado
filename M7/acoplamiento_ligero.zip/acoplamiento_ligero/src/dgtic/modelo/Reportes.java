package dgtic.modelo;

public class Reportes implements Responsabilidades {

    @Override
    public void realizar() {

        System.out.println("Reportes");

    }

}
