package dgtic.modelo;

public interface Responsabilidades {

    public void realizar();

}
