package dgtic.modelo;

public class Calificar implements Responsabilidades {

    @Override
    public void realizar() {

        System.out.println("Calificar");

    }

}
