package dgtic.core.modelo;

public interface ModeloCoche {

    void crear();

}
