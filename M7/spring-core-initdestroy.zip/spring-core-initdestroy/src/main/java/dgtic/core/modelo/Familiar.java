package dgtic.core.modelo;

public class Familiar implements ModeloCoche {

    @Override
    public void crear() {
        System.out.println("Carro familiar");
    }
}
