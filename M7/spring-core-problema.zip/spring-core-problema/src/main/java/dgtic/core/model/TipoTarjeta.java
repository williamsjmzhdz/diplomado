package dgtic.core.model;

public enum TipoTarjeta {
    DEBITO, CREDITO
}
