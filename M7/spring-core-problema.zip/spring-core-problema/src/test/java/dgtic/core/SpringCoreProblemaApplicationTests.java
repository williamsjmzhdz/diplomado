package dgtic.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreProblemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
