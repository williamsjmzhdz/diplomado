package dgtic.modelo;

public class Responsabilidades {

    public Responsabilidades() {
    }

    public void explicarClases() {
        System.out.println("Explica clases");
    }

    public void reportes() {
        System.out.println("Reportes");
    }

    public void calificar() {
        System.out.println("Calificar");
    }

}
