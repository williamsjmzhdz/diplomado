package dgtic.core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCorePojodaotestApplicationTests {

	@Test
	void contextLoads() {
	}

}
