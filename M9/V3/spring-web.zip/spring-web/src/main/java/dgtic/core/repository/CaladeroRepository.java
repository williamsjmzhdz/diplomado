package dgtic.core.repository;

import dgtic.core.model.entities.CaladeroEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CaladeroRepository extends JpaRepository<CaladeroEntity, Integer> {
}
