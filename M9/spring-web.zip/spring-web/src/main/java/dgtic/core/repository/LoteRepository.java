package dgtic.core.repository;

import dgtic.core.model.entities.LoteEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LoteRepository extends JpaRepository<LoteEntity,Integer> {

}
