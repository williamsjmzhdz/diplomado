package dgtic.core.controller.lote;

import dgtic.core.model.entities.LoteEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
// endpoint localhost:8080/tipo/alta-tipo
@RequestMapping(value = "lote")
public class LoteController {

    @GetMapping("alta-lote")
    public String altaLote(Model model) {
        LoteEntity lote = new LoteEntity();
        model.addAttribute("contenido", "Alta de Lote");
        model.addAttribute("lote", lote);
        return "lote/alta-lote";
    }

    /*
    @PostMapping("salvar-tipo")
    public String salvarTipo(@RequestParam("nombre") String nombre, Model model,
                             RedirectAttributes flash) {
        System.out.println("Formulario: " + nombre);
        flash.addFlashAttribute("success", "Se almacenó con éxito.");
        //model.addAttribute("contenido", "Alta de Tipo");
        //model.addAttribute("success", "Se almacenó con éxito.");
        //model.addAttribute("nombre", nombre);
        //return "tipo/alta-tipo";
        return "redirect:/inicio";
    }
    */

    @PostMapping("salvar-lote")
    public String salvarLote(LoteEntity lote, Model model,
                             RedirectAttributes flash) {
        System.out.println("Formulario: " + lote.getNombre() + " " + lote.getId_lote());
        //flash.addFlashAttribute("success", "Se almacenó con éxito.");
        model.addAttribute("contenido", "Alta de Lote");
        model.addAttribute("success", "Se almacenó con éxito.");
        model.addAttribute("lote", lote);
        return "lote/alta-lote";
        //return "redirect:/inicio";
    }

}
