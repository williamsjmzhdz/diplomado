package edu.unam.proyecto_final.dao;

import edu.unam.proyecto_final.model.Rol;

public interface RolDAO extends GenericDAO<Rol, Integer> {}
