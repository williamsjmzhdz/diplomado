package edu.unam.proyecto_final.service;

import edu.unam.proyecto_final.model.Rol;

public interface RolService extends GenericService<Rol, Integer> { }
