package edu.unam.proyecto_final.dao;

import edu.unam.proyecto_final.model.Usuario;

public interface UsuarioDAO extends GenericDAO<Usuario, Integer> {
}
