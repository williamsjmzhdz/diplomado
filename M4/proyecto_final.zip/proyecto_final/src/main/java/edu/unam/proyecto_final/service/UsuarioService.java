package edu.unam.proyecto_final.service;

import edu.unam.proyecto_final.model.Usuario;

public interface UsuarioService extends GenericService<Usuario, Integer> {
}
