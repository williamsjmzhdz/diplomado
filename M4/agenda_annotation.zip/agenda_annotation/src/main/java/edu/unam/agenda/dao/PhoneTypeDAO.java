package edu.unam.agenda.dao;

import edu.unam.agenda.model.PhoneType;

import java.util.List;

public interface PhoneTypeDAO extends GenericDAO<PhoneType, Integer>{}
