package M8E1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M8E1FranciscoJimenezApplication {

	public static void main(String[] args) {
		SpringApplication.run(M8E1FranciscoJimenezApplication.class, args);
	}

}
