package M8E1.datos;

import org.springframework.data.repository.CrudRepository;


/**
 * Alumno: FRANCISCO WILLIAMS JIMÉNEZ HERNÁNDEZ
 * Asignación: Ejercicio 1
 * Fecha de realización: 24/09/2024
 */
public interface RolRepository extends CrudRepository<Rol, Integer> {
}
