package com.bazarboost.model.entity.auxiliar;

public enum TipoTarjeta {
    Débito,
    Crédito
}
