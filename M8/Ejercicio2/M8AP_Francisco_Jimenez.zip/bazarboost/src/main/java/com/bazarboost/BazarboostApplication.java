package com.bazarboost;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BazarboostApplication {

	public static void main(String[] args) {
		SpringApplication.run(BazarboostApplication.class, args);
	}

}
