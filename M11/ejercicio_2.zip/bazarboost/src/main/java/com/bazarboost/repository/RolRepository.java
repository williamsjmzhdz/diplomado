package com.bazarboost.repository;

import com.bazarboost.model.Rol;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

/*
 * Alumno: Francisco Williams Jiménez Hernández
 * Proyecto: Bazarboost
 * */
public interface RolRepository extends CrudRepository<Rol, Integer> {

    /**
     * Encuentra un usuario por su nombre
     *
     * @param nombre nombre del usuario a buscar.
     * @return Objeto optional con el usuario si lo encuentra, Optional.empty() si no lo encuentra
     */
    Optional<Rol> findByNombre(String nombre);

}
